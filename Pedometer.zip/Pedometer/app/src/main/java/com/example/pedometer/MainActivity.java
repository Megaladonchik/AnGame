package com.example.pedometer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private static final int PERMISSION_REQUEST_ACTIVITY_RECOGNITION = 1;

    private SensorManager sensorManager;
    private Sensor stepCounter;
    private Sensor accelerometer;

    private TextView tvSteps;

    private int steps;

    private static final String SAVE_steps = "SAVE_steps";
    private static final String Steps = "0";
    EditText steps_count;
    SharedPreferences.Editor prefEditor;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvSteps = findViewById(R.id.tv_steps);
        sharedPreferences = getSharedPreferences(String.valueOf(SAVE_steps), MODE_PRIVATE);
        String ssteps = sharedPreferences.getString(Steps,"0");
        steps += Integer.parseInt(ssteps);
        tvSteps.setText(ssteps);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        // Check if the device has a step counter sensor
        if (sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR) != null) {
            // Use the step counter sensor
            stepCounter = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
        } else {
            // Use the accelerometer sensor as a fallback
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        }
        // Request permission for activity recognition if needed
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACTIVITY_RECOGNITION},
                    PERMISSION_REQUEST_ACTIVITY_RECOGNITION);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Register the sensor listener
        if (stepCounter != null) {
            sensorManager.registerListener(this, stepCounter, SensorManager.SENSOR_DELAY_NORMAL);
        } else if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Unregister the sensor listener
        String ssteps = tvSteps.getText().toString();
        sensorManager.unregisterListener(this);
        prefEditor = sharedPreferences.edit();
        prefEditor.putString(Steps,ssteps );
        prefEditor.apply();
    }

    @Override

    public void onSensorChanged(SensorEvent event) {

        tvSteps.post(()->{


        // Update the steps values based on the sensor type
        if (event.sensor.getType() == Sensor.TYPE_STEP_DETECTOR) {
            steps ++;
        } else if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                steps++;
        }
        // Update the UI elements with the new values


           tvSteps.setText(String.valueOf(steps));
        });

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Do nothing
    }
    public class drawRectangle extends View{

        public drawRectangle(Context context){
            super(context);
        }

        @Override
        public void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            canvas.save();

            Paint p = new Paint();
            p.setColor(3);

            canvas.restore();
        }
    }
}