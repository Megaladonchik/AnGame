package com.example.gamedraw;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;

import java.util.Timer;

public class GameView extends View {

    private Paint paint = new Paint();
    Sprite monster;

    Sprite scene;

    Sprite moon;
    int x = 0;

    int screenHeight;
    int screenWidth;

    boolean isClose = false;

    Thread timer = new Thread(()->{
       while (!isClose){
           x++;
           postInvalidate();
           Log.e("aaa", String.valueOf(x));
           try {
               Thread.sleep(100);
           } catch (InterruptedException e) {
               throw new RuntimeException(e);
           }
       }
    });

    public GameView(Context context) {
        super(context);

        screenHeight = context.getResources().getDisplayMetrics().heightPixels;
        screenWidth = context.getResources().getDisplayMetrics().widthPixels;

        monster = new Sprite(R.drawable.monster, 300, 300, context);
        monster.setY(screenHeight-monster.getHeight()/2-500);

        scene = new Sprite(R.drawable.scene, screenHeight, screenHeight, context);
        scene.setX(-500);
        scene.setY(0);

        moon = new Sprite(R.drawable.moon, screenWidth*3, screenWidth*2, context);
        moon.setX(0-moon.getWidth()/3);
        moon.setY(screenHeight-screenHeight/3);

    }

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(Color.WHITE);
        x++;

        scene.Draw(canvas);
        moon.Draw(canvas);
        monster.Draw(canvas);

        invalidate();
    }

    public void setAccelerometerData(float x){
        int new_x = (int) ((-x+8.0)*50.0);
        monster.setX((int) new_x);
        scene.setX((int) (x*10.0)-500);
    }

    public void isClose(){
        isClose = true;
    }

}
