package com.example.mycat;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mycat.FreestyleNorm;
import com.example.mycat.R;

import java.util.List;

public class FreestyleNormAdapter extends RecyclerView.Adapter<FreestyleNormAdapter.ViewHolder> {
    private List<FreestyleNorm> normsList;

    public FreestyleNormAdapter(List<FreestyleNorm> normsList) {
        this.normsList = normsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_freestyle_norm, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        FreestyleNorm norm = normsList.get(position);
        holder.bindData(norm);
    }

    @Override
    public int getItemCount() {
        return normsList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView normNameTextView;
        private TextView normValueTextView;

        ViewHolder(View itemView) {
            super(itemView);
            normNameTextView = itemView.findViewById(R.id.tvNormName);
            normValueTextView = itemView.findViewById(R.id.tvNormValue);
        }

        void bindData(FreestyleNorm norm) {
            normNameTextView.setText(norm.getNormName());
            normValueTextView.setText(String.valueOf(norm.getNormValue()));
        }
    }
}

