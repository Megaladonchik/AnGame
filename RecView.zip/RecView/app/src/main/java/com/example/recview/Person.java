package com.example.recview;

public class Person {
    private String name;
    private String departament;
    private String proffession;
    private int imageResourse;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartament() {
        return departament;
    }

    public void setDepartament(String departament) {
        this.departament = departament;
    }

    public String getProffesion(String proffession) {
        return proffession;
    }

    public void setProffession(String proffession) {
        this.proffession = proffession;
    }

    public Integer getImageResourse(Integer imageResourse) {
        return imageResourse;
    }

    public void setImageResourse(Integer imageResourse) {
        this.imageResourse = imageResourse;
    }

}
