package com.example.mycat;

public class StyleDialog {
    private String StyleName;


    public String getStyleName() {
        return StyleName;
    }
    public void setStyleName(String styleName) {
        this.StyleName = styleName;
    }
}
