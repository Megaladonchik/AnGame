package com.example.mycat;


public class Style {
    private String StyleName;

    public int getImageResourse() {return imageResourse;}

    public void setImageResourse(int id) {this.imageResourse = id;}

    private int imageResourse;

    public String getStyleName() {
        return StyleName;
    }

    public void setStyleName(String styleName) {
        this.StyleName = styleName;
    }


}
