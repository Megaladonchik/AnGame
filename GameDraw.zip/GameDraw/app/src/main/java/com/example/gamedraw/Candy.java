package com.example.gamedraw;

public class Candy{

}
