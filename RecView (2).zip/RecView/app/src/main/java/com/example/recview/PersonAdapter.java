package com.example.recview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PersonAdapter extends RecyclerView.Adapter<PersonAdapter.ViewHolder> {
    public static class ViewHolder extends RecyclerView.ViewHolder{
ImageView avatar;
TextView fio;
TextView dep;
TextView prof;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            avatar = itemView.findViewById(R.id.avatar);
            fio = itemView.findViewById(R.id.fio);
            dep = itemView.findViewById(R.id.departament);
            prof = itemView.findViewById(R.id.prof);
        }
        public void setAvatar(int resourse){
            this.avatar.setImageResource(resourse);
        }
        public void setFio(String name){
            this.fio.setText(name);
        }
        public void setDep(String name){
            this.dep.setText(name);
        }
        public void setProf(String name){
            this.prof.setText(name);
        }



    }
    private ArrayList<Person> persons;
    private LayoutInflater inflater;

    public PersonAdapter(Context context, ArrayList<Person> persons){
        this.persons = persons;
        inflater = LayoutInflater.from(context);
    }
    @NonNull
    @Override
    public PersonAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.person_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PersonAdapter.ViewHolder holder, int position) {

        Person item = persons.get(position);
        holder.setFio(item.getName());
        holder.setAvatar(item.getImageResourse());
        holder.setDep(item.getDepartament());
        holder.setProf(item.getProffesion());
    }

    @Override
    public int getItemCount() {
        return persons.size();
    }
}
