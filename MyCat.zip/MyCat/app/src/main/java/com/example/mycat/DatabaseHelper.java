package com.example.mycat;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "freestyle.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Создание таблицы для стилей
        String Styles = "CREATE TABLE IF NOT EXISTS Styles (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "Name TEXT)";
        db.execSQL(Styles);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Обновление базы данных (пример)
        if (oldVersion < newVersion) {
            db.execSQL("DROP TABLE IF EXISTS FreestyleNorms");
            onCreate(db);
        }
    }
    public boolean insertData(String ID, String Name, String First100, String Second100, String Fhird100, String KMS100, String MS100 ) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Name, "Баттерфляй" );

        long result = db.insert("Styles", null, contentValues);

        return result != -1; // если result == -1, данные не были добавлены
    }
}
