package com.example.recview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class NamesAdapter extends RecyclerView.Adapter<NamesAdapter.ViewHolder> {

    public static class ViewHolder extends RecyclerView.ViewHolder{
        final TextView txt;
        public ViewHolder(@NonNull View itemView){
            super(itemView);
            txt = itemView.findViewById(R.id.txt);
        }
    }
    private final LayoutInflater inflater;
    private final List<String> names;


    public NamesAdapter(Context context, List<String> names) {
        inflater = LayoutInflater.from(context);
        this.names = names;
    }

    @NonNull
    @Override
    public NamesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.name_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NamesAdapter.ViewHolder holder, int position) {
    String name = names.get(position);
    holder.txt.setText(String.valueOf(name));
    }

    @Override
    public int getItemCount() {
        return names.size();
    }
}
