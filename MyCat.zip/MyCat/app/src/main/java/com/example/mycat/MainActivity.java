package com.example.mycat;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Dialog dialog;
    ArrayList<Style> styles = new ArrayList<>();

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.style_meny);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.meny_background));



        RecyclerView rv = findViewById(R.id.rvNames);
        StyleAdapter adapter = new StyleAdapter(this, styles);
        rv.setAdapter(adapter);
        rv.setOnClickListener(this::OpenMeny);

        Style s = new Style();
        s.setStyleName("Баттерфляй");
        styles.add(s);
       


        s = new Style();
        s.setStyleName("Спина");
        styles.add(s);

        s = new Style();
        s.setStyleName("Брасс");
        styles.add(s);

        s = new Style();
        s.setStyleName("Кроль");
        styles.add(s);

        s = new Style();
        s.setStyleName("Комплекс");
        styles.add(s);


    }
    public void OpenMeny(View view){
        dialog.show();
    }
}