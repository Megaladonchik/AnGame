package com.example.gamedraw;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;

public class Sprite {
    //Context data
    private Context context;

    //Graphics data
    private Bitmap sprite;

    //coordinate
    private int x=50, y=50;

    //size
    private int width, height;

    public Sprite(int image, int width, int height, Context context){
        this.context = context;
        this.width = width;
        this.height = height;

        Bitmap bitmapSource = BitmapFactory.decodeResource(context.getResources(), image);
        sprite = Bitmap.createScaledBitmap(bitmapSource, width, height,true);
    }

    public void Draw(Canvas canvas){
        canvas.drawBitmap(sprite, (float) x, (float) y,null);
    }

    public void setCoordinate(int x, int y){
        this.x = x;
        this.y = y;
    }

    public void setX(int x){
        this.x = x;
    }
    public void setY(int y){
        this.y = y;
    }

    public int getX(){
        return x;
    }

    public int getY(){
        return x;
    }

    public int getWidth(){
        return width;
    }

    public int getHeight(){
        return height;
    }
}
