package com.example.mycat;

public class Norm {
    private String normName;
    private Double normValue;

    public String getNormName() {
        return normName;
    }

    public void setNormName(String normName) {
        this.normName = normName;
    }

    public Double getNormValue() {
        return normValue;
    }

    public void setNormValue(Double normValue) {
        this.normValue = normValue;
    }

}

