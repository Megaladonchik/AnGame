package com.example.mycat;


public class Style {
    private String StyleName;


    public String getStyleName() {
        return StyleName;
    }

    public void setStyleName(String styleName) {
        this.StyleName = styleName;
    }
}
