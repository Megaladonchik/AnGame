package com.example.game;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.CountDownTimer;
import android.view.MotionEvent;
import android.view.View;

public class GameView extends View {
    int highScoreValue;
    private final int timerInterval = 30;
    private Sprite playerBird;
    private int points = 0;
    private int viewWidth;
    private int viewHeight;
    private Sprite enemyBird;
    boolean a = false;
    int entr = 0;
    private SharedPreferences highScore;

    public GameView(Context context) {
        super(context);
        highScore = context.getSharedPreferences("HighScore", MODE_PRIVATE);
        Bitmap b = BitmapFactory.decodeResource(getResources(), R.drawable.player);
        int w = b.getWidth()/5;
        int h = b.getHeight()/3;
        Rect firstFrame = new Rect(0, 0, w, h);
        playerBird = new Sprite(10, 0, 0, 100, firstFrame, b);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
                if (i == 0 && j == 0) {
                    continue;
                }
                if (i == 2 && j == 3) {
                    continue;
                }
                playerBird.addFrame(new Rect(j * w, i * h, j * w + w, i * w + w));
            }
        }
        Timer t = new Timer();
        t.start();
        b = BitmapFactory.decodeResource(getResources(), R.drawable.enemy);
        w = b.getWidth()/5;
        h = b.getHeight()/3;
        firstFrame = new Rect(4*w, 0, 5*w, h);
        enemyBird = new Sprite(2000, 250, -210, 0, firstFrame, b);
        for (int i = 0; i < 3; i++) {
            for (int j = 4; j >= 0; j--) {
                if (i ==0 && j == 4) {
                    continue;
                }
                if (i ==2 && j == 0) {
                    continue;
                }
                enemyBird.addFrame(new Rect(j*w, i*h, j*w+w, i*w+w));
            }
        }
        highScoreValue = highScore.getInt("score", 0);
    }
    protected void update () {

        if (a == true) {
            playerBird.update(timerInterval);
            enemyBird.update(timerInterval);
            invalidate();
            if (enemyBird.intersect(playerBird)) {
                a = false;

            }
            if (enemyBird.getX() < -enemyBird.getFrameWidth()) {
                teleportEnemy();
                points ++;

            }

            if (playerBird.getY() + playerBird.getFrameHeight() > viewHeight) {
                playerBird.setY(viewHeight - playerBird.getFrameHeight());
                playerBird.setVy(playerBird.getVy());


            } else if (playerBird.getY() < 0) {
                playerBird.setY(0);
                playerBird.setVy(playerBird.getVy());
            }
            if (points > highScoreValue) {
                SharedPreferences.Editor editor = highScore.edit();
                editor.putInt("score", points);
                editor.apply();
            }
        }
        else {


        }
    }
    class Timer extends CountDownTimer {
        public Timer() {
            super(Integer.MAX_VALUE, timerInterval);
        }
        @Override
        public void onTick(long millisUntilFinished) {
            update();
        }
        @Override
        public void onFinish() {
        }
    }
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        viewWidth = w;
        viewHeight = h;
    }
    @Override
    protected void onDraw(Canvas canvas) {
        int highScoreValue = highScore.getInt("score", 0);
        super.onDraw(canvas);
        canvas.drawARGB(250, 127, 199, 255); // заливаем цветом
        playerBird.draw(canvas);
        enemyBird.draw(canvas);
        Paint p = new Paint();
        Paint sc = new Paint();
        Paint nw = new Paint();
        nw.setTextSize(130f);
        nw.setColor(Color.RED);
        sc.setTextSize(130f);
        p.setAntiAlias(true);
        p.setTextSize(100.0f);
        p.setColor(Color.RED);
        if( entr == 0){
            if (a == false) canvas.drawText("FLYING BIRD",   200, 1000, nw);
            if (a == false) canvas.drawText("click to start",   250, 2000, p);
            if (a == false) canvas.drawText("High Score: " + highScoreValue, 300, 1150, p);
            entr++;

        }
        else {
            canvas.drawText(points + "", viewWidth - 100, 70, p);
            if (a == false) canvas.drawText("GAME OVER", 250, 500, sc);
            if (a == false) canvas.drawText("click to restart", 250, 2000, p);
            if (a == false) canvas.drawText("SCORE: " + points, 300, 750, sc);
            if (a == false) canvas.drawText("High Score: " + highScoreValue, 300, 850, p);

        }

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(a == true){
        int eventAction = event.getAction();
        if (eventAction == MotionEvent.ACTION_DOWN) {

            playerBird.setVy(-playerBird.getVy());
        }
        return true;}
        else {

                int eventAction = event.getAction();
                if (eventAction == MotionEvent.ACTION_DOWN) {
                    playerBird.setY(500);
                    enemyBird.setX(2000);
                    points = 0;
                    a = true;
                }
            return true;
        }
    }
    private void teleportEnemy () {
        enemyBird.setX(viewWidth + Math.random() * 500);
        enemyBird.setY(Math.random() * (viewHeight - enemyBird.getFrameHeight()));
    }
}
