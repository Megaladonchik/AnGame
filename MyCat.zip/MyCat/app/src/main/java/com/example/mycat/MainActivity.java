package com.example.mycat;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<Style> styles = new ArrayList<>();


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        RecyclerView rv = findViewById(R.id.rvNames);
        StyleAdapter adapter = new StyleAdapter(this, styles);
        rv.setAdapter(adapter);

        Style s = new Style();
        s.setStyleName("Баттерфляй");
        styles.add(s);

        s = new Style();
        s.setStyleName("Спина");
        styles.add(s);

        s = new Style();
        s.setStyleName("Брасс");
        styles.add(s);

        s = new Style();
        s.setStyleName("Кроль");
        styles.add(s);

        s = new Style();
        s.setStyleName("Комплекс");
        styles.add(s);




    }
}