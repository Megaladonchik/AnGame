package com.example.mycat;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class FreestyleDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "freestyle.db";
    private static final int DATABASE_VERSION = 1;

    public FreestyleDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Создание таблиц для стиля "Freestyle" мужчин
        String createTableQueryMan = "CREATE TABLE IF NOT EXISTS FreestyleNorms (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "normName TEXT," +
                "normValue REAL)";
        db.execSQL(createTableQueryMan);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Обновление базы данных (пример)
        if (oldVersion < newVersion) {
            db.execSQL("DROP TABLE IF EXISTS FreestyleNorms");
            onCreate(db);
        }
    }
}
