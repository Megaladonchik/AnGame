package com.example.recview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    ArrayList<String> names = new ArrayList<>();
    ArrayList<Person> persons = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        names.addAll(Arrays.asList("Виктор", "Трансформатор", "Шаурма"));
        RecyclerView rv = findViewById(R.id.rvNames);
        NamesAdapter adapter = new NamesAdapter(this, names);
        rv.setAdapter(adapter);

    Person p = new Person();
    p.setName("Обама");
    p.setProffession("Президент");
    p.setDepartament("Белый Дом");
    p.getImageResourse(R.drawable.oooobama);

    persons.add(p);

    p = new Person();
        p.setName("Виктор");
        p.setProffession("Электрик");
        p.setDepartament("ТСЖ");
        p.getImageResourse(R.drawable.ooooo);

     persons.add(p);
    }

}