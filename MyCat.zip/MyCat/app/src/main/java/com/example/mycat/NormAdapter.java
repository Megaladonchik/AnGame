package com.example.mycat;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class NormAdapter extends RecyclerView.Adapter<NormAdapter.ViewHolder> {
    private List<Norm> normsList;

    public NormAdapter(List<Norm> normsList) {
        this.normsList = normsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_table_norm, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Norm norm = normsList.get(position);
        holder.bindData(norm);
    }

    @Override
    public int getItemCount() {
        return normsList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView normNameTextView;
        private TextView normValueTextView;

        ViewHolder(View itemView) {
            super(itemView);
            normNameTextView = itemView.findViewById(R.id.tvNormName);
            normValueTextView = itemView.findViewById(R.id.tvNormValue);
        }

        void bindData(Norm norm) {
            normNameTextView.setText(norm.getNormName());
            normValueTextView.setText(String.valueOf(norm.getNormValue()));
        }
    }
}

